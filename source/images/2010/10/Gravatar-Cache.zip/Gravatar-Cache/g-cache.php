<?php
/*
Plugin Name: Gravatar Cache
Plugin URI: http://loo2k.com/gravatar-cache-reset
Description: Gravatar.com cache on your website;
Version: 0.1
Author: LOO2K
Author URI: http://loo2k.com/

*/

function cache_gravatar($avatar) {
  $tmp = strpos($avatar, 'http'); //76
  $g = substr($avatar, $tmp, strpos($avatar, "'", $tmp) - $tmp);//图像地址
  $tmp = strpos($g, 'avatar/') + 7;//31
  $f = substr($g, $tmp, strpos($g, "?", $tmp) - $tmp);//图像名称
  $s = 'size' . substr($avatar,strpos($avatar, "?s=", $tmp) + 3,2);//图像大小 48
  $nogfw = 'http://www.gravatar.com/avatar/' . $f . '?size=' . $s . '.png';//替换成没有被墙的地址
  $w = get_bloginfo('wpurl').'/wp-content/plugins/Gravatar-Cache';//博客地址
  $e = ABSPATH .'/wp-content/plugins/Gravatar-Cache/avatar/'. $f . $s .'.png';//主机图像地址
  $t = 1209600; //14天 单位秒
  if ( !is_file($e) || (time() - filemtime($e)) > $t ) copy($nogfw, $e); //当头像不存在或者图像存在时间超过14天更新
  if ( filesize($e) < 500 ) copy($w.'/avatar/default.png', $e);
  $avatar = strtr($avatar, array($g => $w.'/avatar/' . $f . $s . '.png'));//将原来的地址替换成本地地址
  return $avatar;
}

add_filter('get_avatar', 'cache_gravatar');

?>
